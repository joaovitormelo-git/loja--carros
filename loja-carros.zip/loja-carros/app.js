const express = require("express");
const path = require("path");

// Iniciar Express
const app = express();
const PORT = 3000;
const PUBLIC_DIR = path.join(__dirname, "public");

// Middlewares para processar dados do formulário e JSON
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Servir arquivos estáticos (HTML, CSS, etc.)
app.use(express.static(PUBLIC_DIR));

// Rotas
// Página inicial
app.get("/", (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, "index.html"));
});

// Página de listagem de carros
app.get("/lista-carros", (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, "lista-carros.html"));
});

// Página com formulário de cadastro de carro
app.get("/formulario", (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, "formulario.html"));
});

// Rota para receber os dados do formulário via POST
app.post("/carro", (req, res) => {
  const { modelo, marca, ano, cor, quilometragem, valor } = req.body;

  // Exibindo os dados no console
  console.log("Modelo do carro: " + modelo);
  console.log("Marca do carro: " + marca);
  console.log("Ano do carro: " + ano);
  console.log("Cor do carro: " + cor);
  console.log("Quilometragem do carro: " + quilometragem);
  console.log("Valor do carro: " + valor);

  res.send("Carro cadastrado com sucesso!");
});

// Middleware para rota não encontrada (404)
app.use((req, res) => {
  res.status(404).send("Página não encontrada!");
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});